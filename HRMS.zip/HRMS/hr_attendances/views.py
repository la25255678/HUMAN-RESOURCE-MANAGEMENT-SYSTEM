from django.shortcuts import render, redirect

# Create your views here.
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_attendances import models
from hr_attendances import forms
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator

from django.db.models import Q
from django.views import View
from .models import AttendanceModel



class SearchBy(View):

    def get(self, request):
        search = request.GET.get('search')
        if search:    
            attendance = AttendanceModel.objects.filter(
                Q(name__icontains=search) |  
                Q(join_date__icontains=search) |
                Q(note__icontains=search)   
            )
        else:      
            attendance = AttendanceModel.objects.all()
        return render(request, 'attendance_list.html', {'all_attendances': attendance})

class OrderBy(View):

    def get(self, request):
        order = request.GET.get('order')
        expence = AttendanceModel.objects.all().order_by("-"+ order)
        order_selected = {str(order): 'btn-primary text-white'}
        return render(request, 'attendance_list.html', {'all_attendances': attendance, 'order_selected': order_selected})

class AttendanceListView(LoginRequiredMixin,ListView):
	 paginate_by = 2
	 login_url = 'login'
	 model = models.AttendanceModel
	 context_object_name = 'all_attendances'
	 template_name = 'attendance_list.html'


class AttendanceDetailView(PermissionRequiredMixin,DetailView):
 	 permission_required = 'hr_attendances.add_attendancemodel'
 	 login_url = 'login'
 	 model = models.AttendanceModel
 	 form_class = forms.AttendanceForm
 	 context_object_name = "attendance"
 	 template_name = 'attendance_detail.html'

 	 def get_context_data(self, **kwargs):
				context = super(AttendanceDetailView, self).get_context_data(**kwargs)
				attendance = models.AttendanceModel.objects.get(id=self.kwargs.get('pk'))
				form = forms.AttendanceForm(instance=attendance)
				context['form'] = form
				return context
		 
class AttendanceUpdateView(PermissionRequiredMixin,UpdateView):
	 permission_required = 'hr_attendances.change_attendancemodel'
	 login_url = 'login'
	 success_url = reverse_lazy("attendance_list")
	 model = models.AttendanceModel
	 form_class = forms.AttendanceForm
	 context_object_name = "attendance"
	 template_name = 'attendance_update.html'


class AttendanceCreateView(PermissionRequiredMixin,CreateView):
	 permission_required = 'hr_attendances.add_attendancemodel'
	 login_url = 'login'
	 success_url = reverse_lazy("attendance_list")
	 model = models.AttendanceModel
	 form_class = forms.AttendanceForm
	 template_name = 'attendance_create.html'


class AttendanceDeleteView(PermissionRequiredMixin,DeleteView):
	 permission_required = 'hr_attendances.delete_attendancemodel'
	 login_url = 'login'
	 # success_url = reverse_lazy("attendance_list")
	 # model = models.AttendanceModel
	 # context_object_name = "atance"
	 # template_name = 'attendance_delete.html'

	 def get(self, request, pk):
			attendance = models.AttendanceModel.objects.get(id=pk)  
			attendance.delete()
			return redirect('attendance_list')