from django import forms
from django.forms import widgets
from .models import AttendanceModel

STATUS_CHOICES =(
('draft', 'draft'),
('Confirm', 'confirm'),
('Cancel', 'cancel')
)

class AttendanceForm(forms.ModelForm):

    class Meta:
        model = AttendanceModel
        fields = "__all__"

        labels = {
        'name':'Enter Name', 
        'join_date':'Enter Join Date',
        'note':'Enter Note', 
        'birthday_date':'Enter Birthday Date',
        'check_in':'Enter Check In',
        'check_out':'Enter Check Out',
        'department':'Enter Department',
        'status':'Enter Status',
        

        }

        widgets = {
        'name': widgets.TextInput(attrs={'placeholder':'Attendance Name', 'class': 'form-control'}),
        'join_date': widgets.DateInput(attrs={'placeholder':'Enter Join Date', 'type': 'date','class': 'form-control'}),
        'note': widgets.TextInput(attrs={'placeholder':'Internal Note', 'class': 'form-control'}),
        'birthday_date': widgets.DateInput(attrs={'placeholder':'Enter Birthday Date', 'type': 'date', 'class': 'form-control'}),
        'check_in': widgets.TimeInput(attrs={'placeholder':'Enter Check In', 'type': 'time', 'class': 'form-control'}),
        'check_out': widgets.TimeInput(attrs={'placeholder':'Enter Check Out', 'type': 'time', 'class': 'form-control'}),
        'department': widgets.TextInput(attrs={'placeholder':'Department', 'class': 'form-control'}),
        'status': widgets.Select(choices=STATUS_CHOICES),
        'attachment': widgets.ClearableFileInput(),


        }
