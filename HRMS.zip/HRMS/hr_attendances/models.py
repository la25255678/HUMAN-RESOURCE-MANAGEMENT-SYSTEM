from django.db import models
from django.utils import timezone

class AttendanceModel(models.Model):

     class Meta:

         permissions = (
            ("view_attendancemodel", "Can view attendance model"),
         )
   
     name = models.CharField(max_length=20, verbose_name='Name')
     join_date = models.DateField(verbose_name='Join Date', default=timezone.now)
     note = models.TextField(max_length=100, verbose_name='Note') 
     birthday_date = models.DateField(verbose_name='Birthday Date', default=timezone.now)
     check_in = models.TimeField(verbose_name='Check In', default=timezone.now)
     check_out = models.TimeField(verbose_name='Check Out', default=timezone.now)
     department = models.CharField(max_length=100, verbose_name='Department', default='draft')
     status = models.CharField(max_length=10, verbose_name='Status', default=' ')
     attachment = models.ImageField(verbose_name='Attachment', default=None, blank=True)



     def __str__(self):
        return self.name