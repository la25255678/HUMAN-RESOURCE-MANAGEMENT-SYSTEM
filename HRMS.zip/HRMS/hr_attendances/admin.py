from django.contrib import admin

# Register your models here.
from hr_attendances.models import AttendanceModel
admin.site.register(AttendanceModel)