from django.contrib import admin

# Register your models here.
from hr_pages.models import PageModel
admin.site.register(PageModel)
