from django.apps import AppConfig


class HrPagesConfig(AppConfig):
    name = 'hr_pages'
