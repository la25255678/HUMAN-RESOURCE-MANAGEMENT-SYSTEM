from django.shortcuts import render, redirect

# Create your views here.
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_pages import models
from hr_pages import forms

class PageListView(ListView):
	 model = models.PageModel
	 context_object_name = 'all_pages'
	 template_name = 'page_list.html'



# class ResumeDetailView(DetailView):
#  	 model = models.ResumeModel
#  	 context_object_name = "resume"
#  	 template_name = 'resume_detail.html'
		 
# class ResumeUpdateView(UpdateView):
# 	 success_url = reverse_lazy("resume_list")
# 	 model = models.ResumeModel
# 	 form_class = forms.ResumeForm
# 	 context_object_name = "resume"
# 	 template_name = 'resume_update.html'


# class ResumeCreateView(CreateView):
# 	 success_url = reverse_lazy("resume_list")
# 	 model = models.ResumeModel
# 	 form_class = forms.ResumeForm
# 	 template_name = 'resume_create.html'


# class ResumeDeleteView(DeleteView):
# 	 success_url = reverse_lazy("resume_list")
# 	 model = models.ResumeModel
# 	 context_object_name = "resume"
# 	 template_name = 'resume_delete.html'