from django.db import models

class PageModel(models.Model):

     name = models.CharField(max_length=20, verbose_name='Name')

     def __str__(self):
       return self.name
