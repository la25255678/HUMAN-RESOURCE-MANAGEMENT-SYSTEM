**hr_payrole,hr_attendance,hr_expences refrance hr_recirutments

**desing by tooplatemore and odoo website

**toopaltemore website address https://www.tooplate.com/

**odoo webiste address https://www.odoo.com/

**admin password
	user= admin
	password=superuser

**slider by my creations