-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 05, 2023 at 06:58 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hrms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=81 ;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session'),
(19, 'Can add employee model', 7, 'add_employeemodel'),
(20, 'Can change employee model', 7, 'change_employeemodel'),
(21, 'Can delete employee model', 7, 'delete_employeemodel'),
(22, 'Can add contract model', 8, 'add_contractmodel'),
(23, 'Can change contract model', 8, 'change_contractmodel'),
(24, 'Can delete contract model', 8, 'delete_contractmodel'),
(25, 'Can add job model', 9, 'add_jobmodel'),
(26, 'Can change job model', 9, 'change_jobmodel'),
(27, 'Can delete job model', 9, 'delete_jobmodel'),
(28, 'Can add department model', 10, 'add_departmentmodel'),
(29, 'Can change department model', 10, 'change_departmentmodel'),
(30, 'Can delete department model', 10, 'delete_departmentmodel'),
(31, 'Can add resume model', 11, 'add_resumemodel'),
(32, 'Can change resume model', 11, 'change_resumemodel'),
(33, 'Can delete resume model', 11, 'delete_resumemodel'),
(34, 'Can view employee model', 7, 'view_employeemodel'),
(35, 'Can view contract model', 8, 'view_contractmodel'),
(36, 'Can view job model', 9, 'view_jobmodel'),
(37, 'Can view department model', 10, 'view_departmentmodel'),
(38, 'Can view resume model', 11, 'view_resumemodel'),
(39, 'Can add job tag model', 12, 'add_jobtagmodel'),
(40, 'Can change job tag model', 12, 'change_jobtagmodel'),
(41, 'Can delete job tag model', 12, 'delete_jobtagmodel'),
(42, 'Can add contract tag model', 13, 'add_contracttagmodel'),
(43, 'Can change contract tag model', 13, 'change_contracttagmodel'),
(44, 'Can delete contract tag model', 13, 'delete_contracttagmodel'),
(45, 'Can add employee tag model', 14, 'add_employeetagmodel'),
(46, 'Can change employee tag model', 14, 'change_employeetagmodel'),
(47, 'Can delete employee tag model', 14, 'delete_employeetagmodel'),
(48, 'Can add resume tag model', 15, 'add_resumetagmodel'),
(49, 'Can change resume tag model', 15, 'change_resumetagmodel'),
(50, 'Can delete resume tag model', 15, 'delete_resumetagmodel'),
(51, 'Can add payrole model', 16, 'add_payrolemodel'),
(52, 'Can change payrole model', 16, 'change_payrolemodel'),
(53, 'Can delete payrole model', 16, 'delete_payrolemodel'),
(54, 'Can add resume model', 17, 'add_resumemodel'),
(55, 'Can change resume model', 17, 'change_resumemodel'),
(56, 'Can delete resume model', 17, 'delete_resumemodel'),
(57, 'Can add attendance model', 17, 'add_attendancemodel'),
(58, 'Can change attendance model', 17, 'change_attendancemodel'),
(59, 'Can delete attendance model', 17, 'delete_attendancemodel'),
(60, 'Can add atance model', 18, 'add_atancemodel'),
(61, 'Can change atance model', 18, 'change_atancemodel'),
(62, 'Can delete atance model', 18, 'delete_atancemodel'),
(63, 'Can add atance model', 19, 'add_atancemodel'),
(64, 'Can change atance model', 19, 'change_atancemodel'),
(65, 'Can delete atance model', 19, 'delete_atancemodel'),
(66, 'Can add expence model', 20, 'add_expencemodel'),
(67, 'Can change expence model', 20, 'change_expencemodel'),
(68, 'Can delete expence model', 20, 'delete_expencemodel'),
(69, 'Can add payslip model', 21, 'add_payslipmodel'),
(70, 'Can change payslip model', 21, 'change_payslipmodel'),
(71, 'Can delete payslip model', 21, 'delete_payslipmodel'),
(72, 'Can add payslip model', 22, 'add_payslipmodel'),
(73, 'Can change payslip model', 22, 'change_payslipmodel'),
(74, 'Can delete payslip model', 22, 'delete_payslipmodel'),
(75, 'Can add home model', 23, 'add_homemodel'),
(76, 'Can change home model', 23, 'change_homemodel'),
(77, 'Can delete home model', 23, 'delete_homemodel'),
(78, 'Can add page model', 24, 'add_pagemodel'),
(79, 'Can change page model', 24, 'change_pagemodel'),
(80, 'Can delete page model', 24, 'delete_pagemodel');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$100000$DAqzlflqYlOa$ax5PgqeoDCJYEQ/JGirBV3Q1CVW/tjMUMIX3htc8Zvc=', '2023-07-01 15:31:08', 1, 'admin', 'Administractor', '', 'admin@gmail.com', 1, 1, '2023-03-18 03:48:00'),
(2, 'pbkdf2_sha256$100000$gIgwK3ly4WeA$hFAh9atbnIHZGY7skMG40uJVl+bd6zFe7AergCuhNNk=', '2023-06-27 13:13:07', 0, 'normaluser', 'Normal', 'User', '', 0, 1, '2023-04-23 03:59:37'),
(3, 'pbkdf2_sha256$100000$dxJ0tS5e2lUJ$XfJemLDPo+bkP+6x7TtO0TDgcU0B6WKAeJ6fIVxhfbQ=', '2023-06-09 13:48:41', 0, 'viewuser', 'View', 'User', '', 0, 1, '2023-04-23 04:17:09'),
(4, 'pbkdf2_sha256$100000$hmVqnKfXBT8e$RaArwhh8dymwGnN45YRjdVElX6T6+EC9a/S4MjaciOE=', '2023-05-13 03:04:50', 0, 'createuser', 'Create', 'User', '', 0, 1, '2023-04-23 14:33:05'),
(5, 'pbkdf2_sha256$100000$UbyQMiCWmXNW$OYNS4GDFwudNtQwJX+5OLRtL0U772V2pTiHbJtJ5pYY=', '2023-04-29 14:56:58', 0, 'updateuser', 'Update', 'User', '', 0, 1, '2023-04-29 04:12:53'),
(6, 'pbkdf2_sha256$100000$iFuob83eXq3D$f1OvSvwEbNVcTxpocHL/w208PqxVP22Wjmtghw1BFOU=', '2023-04-29 15:04:29', 0, 'deleteuser', 'Deleate', 'User', '', 0, 1, '2023-04-29 04:13:48');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `auth_user_user_permissions`
--

INSERT INTO `auth_user_user_permissions` (`id`, `user_id`, `permission_id`) VALUES
(1, 3, 34),
(9, 3, 35),
(4, 3, 36),
(5, 3, 37),
(6, 3, 38),
(14, 4, 19),
(15, 4, 22),
(16, 4, 25),
(17, 4, 28),
(18, 4, 31),
(10, 4, 34),
(2, 4, 35),
(11, 4, 36),
(12, 4, 37),
(13, 4, 38),
(24, 5, 20),
(25, 5, 23),
(26, 5, 26),
(27, 5, 29),
(7, 5, 32),
(19, 5, 34),
(20, 5, 35),
(21, 5, 36),
(22, 5, 37),
(23, 5, 38),
(34, 6, 21),
(35, 6, 24),
(36, 6, 27),
(37, 6, 30),
(28, 6, 33),
(29, 6, 34),
(30, 6, 35),
(31, 6, 36),
(32, 6, 37),
(33, 6, 38);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2023-03-18 04:14:38', '1', 'Kyaw Kyaw', 1, '[{"added": {}}]', 7, 1),
(2, '2023-03-25 04:25:18', '1', 'ContractModel object (1)', 1, '[{"added": {}}]', 8, 1),
(3, '2023-04-01 03:25:45', '1', 'JobModel object (1)', 1, '[{"added": {}}]', 9, 1),
(4, '2023-04-02 03:18:51', '1', 'DepartmentModel object (1)', 1, '[{"added": {}}]', 10, 1),
(5, '2023-04-02 03:31:36', '2', 'DepartmentModel object (2)', 1, '[{"added": {}}]', 10, 1),
(6, '2023-04-02 03:48:45', '1', 'DepartmentModel object (1)', 2, '[{"changed": {"fields": ["meeting_date"]}}]', 10, 1),
(7, '2023-04-02 15:07:10', '1', 'Jon', 1, '[{"added": {}}]', 11, 1),
(8, '2023-04-23 03:46:45', '1', 'admin', 2, '[{"changed": {"fields": ["first_name"]}}]', 4, 1),
(9, '2023-04-23 03:59:37', '2', 'normaluser', 1, '[{"added": {}}]', 4, 1),
(10, '2023-04-23 04:00:21', '2', 'normaluser', 2, '[{"changed": {"fields": ["first_name", "last_name"]}}]', 4, 1),
(11, '2023-04-23 04:17:10', '3', 'viewuser', 1, '[{"added": {}}]', 4, 1),
(12, '2023-04-23 04:29:39', '3', 'viewuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(13, '2023-04-23 04:30:22', '3', 'viewuser', 2, '[{"changed": {"fields": ["first_name", "last_name"]}}]', 4, 1),
(14, '2023-04-23 14:29:50', '3', 'viewuser', 2, '[]', 4, 1),
(15, '2023-04-23 14:33:05', '4', 'createuser', 1, '[{"added": {}}]', 4, 1),
(16, '2023-04-23 14:33:35', '4', 'createuser', 2, '[{"changed": {"fields": ["first_name", "last_name"]}}]', 4, 1),
(17, '2023-04-23 14:37:05', '4', 'createuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(18, '2023-04-23 14:56:30', '2', 'normaluser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(19, '2023-04-29 03:48:35', '3', 'viewuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(20, '2023-04-29 03:51:56', '3', 'viewuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(21, '2023-04-29 04:08:54', '3', 'viewuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(22, '2023-04-29 04:10:54', '3', 'viewuser', 2, '[]', 4, 1),
(23, '2023-04-29 04:12:53', '5', 'updateuser', 1, '[{"added": {}}]', 4, 1),
(24, '2023-04-29 04:13:11', '5', 'updateuser', 2, '[{"changed": {"fields": ["first_name", "last_name"]}}]', 4, 1),
(25, '2023-04-29 04:13:48', '6', 'deleteuser', 1, '[{"added": {}}]', 4, 1),
(26, '2023-04-29 04:14:01', '6', 'deleteuser', 2, '[{"changed": {"fields": ["first_name", "last_name"]}}]', 4, 1),
(27, '2023-04-29 04:23:11', '5', 'updateuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(28, '2023-04-29 14:32:31', '3', 'viewuser', 2, '[]', 4, 1),
(29, '2023-04-29 14:33:25', '3', 'viewuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(30, '2023-04-29 14:45:37', '4', 'createuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(31, '2023-04-29 14:55:54', '5', 'updateuser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(32, '2023-04-29 15:01:26', '6', 'deleteuser', 2, '[{"changed": {"fields": ["user_permissions", "last_login"]}}]', 4, 1),
(33, '2023-04-30 02:39:57', '2', 'normaluser', 2, '[{"changed": {"fields": ["user_permissions"]}}]', 4, 1),
(34, '2023-04-30 04:35:08', '1', 'Full time', 1, '[{"added": {}}]', 14, 1),
(35, '2023-04-30 04:35:22', '2', 'Part Time', 1, '[{"added": {}}]', 14, 1),
(36, '2023-04-30 04:35:39', '3', 'Free Leanser', 1, '[{"added": {}}]', 14, 1),
(37, '2023-04-30 04:35:47', '4', 'Free Leanser', 1, '[{"added": {}}]', 14, 1),
(38, '2023-05-05 14:56:19', '1', 'First Interview', 1, '[{"added": {}}]', 13, 1),
(39, '2023-05-05 14:56:35', '2', 'Second Interview', 1, '[{"added": {}}]', 13, 1),
(40, '2023-05-05 14:56:58', '1', 'Close', 1, '[{"added": {}}]', 12, 1),
(41, '2023-05-05 14:57:04', '2', 'Open', 1, '[{"added": {}}]', 12, 1),
(42, '2023-05-06 03:16:56', '1', 'First Interview', 1, '[{"added": {}}]', 15, 1),
(43, '2023-05-06 03:17:03', '2', 'Second Interview', 1, '[{"added": {}}]', 15, 1),
(44, '2023-05-06 03:25:24', '9', 'Database Adin', 1, '[{"added": {}}]', 9, 1),
(45, '2023-05-06 03:57:55', '1', 'Web Department', 1, '[{"added": {}}]', 9, 1),
(46, '2023-05-06 04:11:39', '7', 'Maung Maung', 1, '[{"added": {}}]', 7, 1),
(47, '2023-05-06 04:27:12', '1', 'khin khin', 1, '[{"added": {}}]', 8, 1),
(48, '2023-05-06 04:32:49', '8', 'khin khin', 1, '[{"added": {}}]', 11, 1),
(49, '2023-05-07 03:43:29', '6', 'htoo mon', 2, '[{"changed": {"fields": ["job", "tags"]}}]', 7, 1),
(50, '2023-05-07 03:54:24', '2', 'Senior Developer', 1, '[{"added": {}}]', 9, 1),
(51, '2023-05-07 03:57:01', '7', 'Maung Maung', 2, '[{"changed": {"fields": ["tags"]}}]', 7, 1),
(52, '2023-05-07 04:11:23', '1', 'khin khin', 2, '[{"changed": {"fields": ["attachment"]}}]', 8, 1),
(53, '2023-05-07 04:12:25', '2', 'Kyaw Kyaw', 1, '[{"added": {}}]', 8, 1),
(54, '2023-05-07 04:18:33', '1', 'khin khin', 2, '[{"changed": {"fields": ["employee", "tags"]}}]', 8, 1),
(55, '2023-05-07 14:03:20', '2', 'Senior Developer', 2, '[{"changed": {"fields": ["department"]}}]', 9, 1),
(56, '2023-05-07 15:02:17', '2', 'Senior Developer', 2, '[{"changed": {"fields": ["department"]}}]', 9, 1),
(57, '2023-05-07 15:04:56', '2', 'Senior Developer', 2, '[{"changed": {"fields": ["department"]}}]', 9, 1),
(58, '2023-05-12 15:07:59', '2', 'Senior Developer', 2, '[{"changed": {"fields": ["attachment", "department"]}}]', 9, 1),
(59, '2023-05-12 15:08:44', '1', 'Web Department', 2, '[{"changed": {"fields": ["attachment", "department"]}}]', 9, 1),
(60, '2023-05-12 15:25:06', '8', 'khin khin', 2, '[{"changed": {"fields": ["attachment", "employee"]}}]', 11, 1),
(61, '2023-05-12 15:25:29', '1', 'Jon Hoop', 2, '[{"changed": {"fields": ["employee", "tags"]}}]', 11, 1),
(62, '2023-05-12 15:27:42', '7', 'khin', 2, '[{"changed": {"fields": ["attachment", "employee", "tags"]}}]', 11, 1),
(63, '2023-05-12 15:29:57', '1', 'Web Department', 2, '[{"changed": {"fields": ["department"]}}]', 9, 1),
(64, '2023-05-13 03:47:35', '8', 'khin khin', 2, '[{"changed": {"fields": ["attachment", "employee"]}}]', 11, 1),
(65, '2023-05-13 03:52:48', '2', 'Senior Developer', 2, '[{"changed": {"fields": ["tags"]}}]', 9, 1),
(66, '2023-06-07 04:58:44', '8', 'khin khin', 2, '[{"changed": {"fields": ["tags"]}}]', 11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(18, 'hr_atances', 'atancemodel'),
(17, 'hr_attendances', 'attendancemodel'),
(8, 'hr_contracts', 'contractmodel'),
(10, 'hr_departments', 'departmentmodel'),
(7, 'hr_employees', 'employeemodel'),
(20, 'hr_expences', 'expencemodel'),
(19, 'hr_expenses', 'atancemodel'),
(23, 'hr_homes', 'homemodel'),
(9, 'hr_jobs', 'jobmodel'),
(24, 'hr_pages', 'pagemodel'),
(16, 'hr_payroles', 'payrolemodel'),
(22, 'hr_payroleslips', 'payslipmodel'),
(21, 'hr_payslip', 'payslipmodel'),
(11, 'hr_recruitments', 'resumemodel'),
(13, 'hr_tags', 'contracttagmodel'),
(14, 'hr_tags', 'employeetagmodel'),
(12, 'hr_tags', 'jobtagmodel'),
(15, 'hr_tags', 'resumetagmodel'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2023-03-18 03:44:17'),
(2, 'auth', '0001_initial', '2023-03-18 03:44:17'),
(3, 'admin', '0001_initial', '2023-03-18 03:44:17'),
(4, 'admin', '0002_logentry_remove_auto_add', '2023-03-18 03:44:17'),
(5, 'contenttypes', '0002_remove_content_type_name', '2023-03-18 03:44:17'),
(6, 'auth', '0002_alter_permission_name_max_length', '2023-03-18 03:44:18'),
(7, 'auth', '0003_alter_user_email_max_length', '2023-03-18 03:44:18'),
(8, 'auth', '0004_alter_user_username_opts', '2023-03-18 03:44:18'),
(9, 'auth', '0005_alter_user_last_login_null', '2023-03-18 03:44:18'),
(10, 'auth', '0006_require_contenttypes_0002', '2023-03-18 03:44:18'),
(11, 'auth', '0007_alter_validators_add_error_messages', '2023-03-18 03:44:18'),
(12, 'auth', '0008_alter_user_username_max_length', '2023-03-18 03:44:18'),
(13, 'auth', '0009_alter_user_last_name_max_length', '2023-03-18 03:44:18'),
(14, 'sessions', '0001_initial', '2023-03-18 03:44:18'),
(15, 'hr_employees', '0001_initial', '2023-03-18 04:13:23'),
(18, 'hr_departments', '0001_initial', '2023-04-02 03:16:43'),
(19, 'hr_recruitments', '0001_initial', '2023-04-02 15:04:32'),
(20, 'hr_employees', '0002_auto_20230423_1057', '2023-04-23 04:28:31'),
(23, 'hr_departments', '0002_auto_20230429_1020', '2023-04-29 03:51:12'),
(24, 'hr_recruitments', '0002_auto_20230429_1037', '2023-04-29 04:08:28'),
(25, 'hr_tags', '0001_initial', '2023-04-30 04:32:19'),
(26, 'hr_tags', '0002_contracttagmodel_employeetagmodel_resumetagmodel', '2023-04-30 04:32:19'),
(27, 'hr_departments', '0002_auto_20230429_1005', '2023-04-30 04:38:22'),
(29, 'hr_jobs', '0001_initial', '2023-05-06 03:43:24'),
(30, 'hr_employees', '0002_auto_20230423_1049', '2023-05-06 04:09:08'),
(31, 'hr_contracts', '0001_initial', '2023-05-06 04:25:44'),
(32, 'hr_recruitments', '0002_auto_20230429_1005', '2023-05-06 04:30:51'),
(59, 'hr_payroleslips', '0001_initial', '2023-05-31 09:44:40'),
(60, 'hr_payroles', '0001_initial', '2023-06-02 08:24:13'),
(61, 'hr_attendances', '0001_initial', '2023-06-02 09:23:37'),
(62, 'hr_homes', '0001_initial', '2023-06-06 04:02:53'),
(63, 'hr_pages', '0001_initial', '2023-06-06 14:28:30'),
(64, 'hr_expences', '0001_initial', '2023-06-07 04:37:29'),
(65, 'hr_expences', '0002_auto_20230607_1107', '2023-06-07 04:37:29');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('jt7319putqo22w4nfy3lfod3xt1boryh', 'ZGY3YTE1ZDFlMmEyOTNlZGM2Nzc3YmRmZTJmMDdjMjIzOTRmNzg2Mjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxMzZkZTE3MmIxYThlOGU0ODk1YmZjNmI3MTU3ZjYxOWYyYTk4NTgzIn0=', '2023-07-15 15:31:08'),
('kbi1mef6iq4qve7ke6idjcz54uw6jga4', 'NWUxZjQ4NTEzZmE3YTAyYmExODk2NDQzY2UzMzgwYzZhNzRkMmVkNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5YWU4NzgzYzVkZGU1ZGNlYWEzMWU4ZjA1OGY5M2JmYjRhMTZkMzc2In0=', '2023-04-08 04:24:04'),
('m82sh5w5b7ze280f9szzl2kagq1ijk32', 'NWUxZjQ4NTEzZmE3YTAyYmExODk2NDQzY2UzMzgwYzZhNzRkMmVkNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5YWU4NzgzYzVkZGU1ZGNlYWEzMWU4ZjA1OGY5M2JmYjRhMTZkMzc2In0=', '2023-05-29 15:28:43'),
('mleur5koz261bk336iguhs5qxqmj8tul', 'ZGY3YTE1ZDFlMmEyOTNlZGM2Nzc3YmRmZTJmMDdjMjIzOTRmNzg2Mjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxMzZkZTE3MmIxYThlOGU0ODk1YmZjNmI3MTU3ZjYxOWYyYTk4NTgzIn0=', '2023-06-03 02:51:48'),
('r2jx8zimu6cv5mhpvdzsw7vlxvg38rcr', 'MjQ0NzIwODRlMjA2MWFkZTYyMjYzODczN2M4YzcxMTlmMTM2Nzg4OTp7Il9hdXRoX3VzZXJfaWQiOiI2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MzExYTJjM2QxZmVhNGE4OGQzYWE1ODU4OWQwZjk2OTc1YjdkNDFkIn0=', '2023-05-13 15:04:29'),
('x0ovdv2fpjiarmfbng91vaefnel0uo9y', 'ZGY3YTE1ZDFlMmEyOTNlZGM2Nzc3YmRmZTJmMDdjMjIzOTRmNzg2Mjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxMzZkZTE3MmIxYThlOGU0ODk1YmZjNmI3MTU3ZjYxOWYyYTk4NTgzIn0=', '2023-06-23 14:05:03'),
('xj586ah2hf978u21nhzh02eazuybzn3h', 'NWUxZjQ4NTEzZmE3YTAyYmExODk2NDQzY2UzMzgwYzZhNzRkMmVkNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5YWU4NzgzYzVkZGU1ZGNlYWEzMWU4ZjA1OGY5M2JmYjRhMTZkMzc2In0=', '2023-04-01 03:49:50'),
('xziy8yagieh9w6b56oyfcepc8xajp2wj', 'ZGY3YTE1ZDFlMmEyOTNlZGM2Nzc3YmRmZTJmMDdjMjIzOTRmNzg2Mjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxMzZkZTE3MmIxYThlOGU0ODk1YmZjNmI3MTU3ZjYxOWYyYTk4NTgzIn0=', '2023-07-11 13:13:36');

-- --------------------------------------------------------

--
-- Table structure for table `hr_attendances_attendancemodel`
--

CREATE TABLE IF NOT EXISTS `hr_attendances_attendancemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `join_date` date NOT NULL,
  `note` longtext NOT NULL,
  `birthday_date` date NOT NULL,
  `check_in` time NOT NULL,
  `check_out` time NOT NULL,
  `department` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `attachment` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hr_attendances_attendancemodel`
--

INSERT INTO `hr_attendances_attendancemodel` (`id`, `name`, `join_date`, `note`, `birthday_date`, `check_in`, `check_out`, `department`, `status`, `attachment`) VALUES
(1, 'Khin Khin', '2013-06-02', 'hopwok', '2023-06-21', '20:02:29', '17:02:29', 'Hr Dp', 'draft', '611b5f8da375891b5883b83294527a15_XFvUeVn.jpg'),
(3, 'pyae phyo', '2023-06-08', 'Your developer is good job', '2023-06-08', '08:28:05', '17:28:05', 'senior', 'Confirm', 'bunny-landscape_nF0blPq.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hr_contracts_contractmodel`
--

CREATE TABLE IF NOT EXISTS `hr_contracts_contractmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `rank` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `note` longtext NOT NULL,
  `status` varchar(10) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `create_date` datetime NOT NULL,
  `attachment` varchar(100) NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hr_contracts_contrac_employee_id_4d158874_fk_hr_employ` (`employee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hr_contracts_contractmodel`
--

INSERT INTO `hr_contracts_contractmodel` (`id`, `name`, `rank`, `start_date`, `end_date`, `note`, `status`, `is_active`, `create_date`, `attachment`, `employee_id`) VALUES
(1, 'khin khin', 3, '2023-05-01', '2023-05-06', 'eww', 'draft', 0, '2023-05-02 04:26:00', 'bunny-landscape_o1Neq6M.jpg', 5),
(2, 'Kyaw Kyaw', 3, '2023-05-01', '2023-05-06', 'sdsf', 'draft', 1, '2023-05-07 04:11:43', 'bunny-landscape_D7p0IrJ.jpg', 3),
(3, 'KO KO', 45, '2023-05-29', '2023-06-03', 'THOWPAOJK', 'Open', 1, '2002-02-01 01:02:00', '611b5f8da375891b5883b83294527a15.jpg', 6);

-- --------------------------------------------------------

--
-- Table structure for table `hr_contracts_contractmodel_tags`
--

CREATE TABLE IF NOT EXISTS `hr_contracts_contractmodel_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractmodel_id` int(11) NOT NULL,
  `contracttagmodel_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hr_contracts_contractmod_contractmodel_id_contrac_1b15c8af_uniq` (`contractmodel_id`,`contracttagmodel_id`),
  KEY `hr_contracts_contrac_contracttagmodel_id_ce805036_fk_hr_tags_c` (`contracttagmodel_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hr_contracts_contractmodel_tags`
--

INSERT INTO `hr_contracts_contractmodel_tags` (`id`, `contractmodel_id`, `contracttagmodel_id`) VALUES
(2, 1, 2),
(3, 2, 1),
(4, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_departments_departmentmodel`
--

CREATE TABLE IF NOT EXISTS `hr_departments_departmentmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `sequence` int(11) NOT NULL,
  `meeting_date` date NOT NULL,
  `total_employees` varchar(20) NOT NULL,
  `note` longtext NOT NULL,
  `status` varchar(10) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `create_date` datetime NOT NULL,
  `attachment` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `hr_departments_departmentmodel`
--

INSERT INTO `hr_departments_departmentmodel` (`id`, `name`, `sequence`, `meeting_date`, `total_employees`, `note`, `status`, `is_active`, `create_date`, `attachment`) VALUES
(1, 'HR Department', 24, '2023-04-02', '4', 'For this page', 'draft', 1, '2023-04-02 06:00:00', 'istockphoto-1145618475-612x612_Y6A4bpy.jpg'),
(4, 'Sein htoo', 21, '2023-04-04', '13', 'this ia a very good', 'draft', 0, '2023-04-04 15:46:00', 'depositphotos_219805072-stock-photo-view-place-bourse-bordeaux-franc_1v0qU0Q.jpg'),
(5, 'lwin lwin', 2, '2023-04-30', '13', 'this ia a very good', 'Confirm', 1, '2023-04-30 03:59:00', '301_1_1ScnuO9.jpg'),
(6, 'Hr Software Departme', 23, '2023-06-29', '12', 'This meating is for human resource menage system.', 'Confirm', 1, '2023-06-27 13:15:00', 'wp9378858.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hr_employees_employeemodel`
--

CREATE TABLE IF NOT EXISTS `hr_employees_employeemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `birthday` date NOT NULL,
  `address` longtext NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `is_married` tinyint(1) NOT NULL,
  `joining_date` datetime NOT NULL,
  `image` varchar(100) NOT NULL,
  `job_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `hr_employees_employeemodel`
--

INSERT INTO `hr_employees_employeemodel` (`id`, `name`, `age`, `birthday`, `address`, `email`, `gender`, `is_married`, `joining_date`, `image`, `job_id`) VALUES
(2, 'ko ko zin', 25, '2023-03-01', 'Yangon', 'ko@gmail.com', 'male', 1, '2023-03-03 10:26:00', '6._Myanmar_Shrimp_Curry.jpg', 1),
(3, 'khin khin', 25, '2023-03-28', 'Yangon', 'khin@gmail.com', 'female', 1, '2023-03-09 09:37:00', '301_1_MZV0ywU.jpg', 2),
(4, 'min Htoo', 25, '2023-04-11', 'Yangon', 'min@gmail.com', 'male', 0, '2022-11-10 20:59:00', '301_1_aEFl3p5.jpg', 0),
(5, 'min min', 25, '2023-04-14', 'Yangon', 'min@gmi.com', 'female', 1, '2023-04-20 10:13:00', '301_1_ZVXKKa5.jpg', 0),
(6, 'htoo mon', 25, '1998-02-04', 'Mandalay', 'htoo@gmail.com', 'male', 0, '2023-04-30 09:41:00', 'Inkedb2_2_kDQ04TH.jpg', 2),
(7, 'Maung Maung', 25, '1997-05-06', 'heiwooq', 'mg@gmail.com', 'male', 0, '1902-04-15 04:10:14', 'shoes.jpg', 1),
(8, 'JON  ', 25, '1997-02-03', 'Mandalay', 'jon@gmail.com', 'male', 1, '2023-05-01 10:34:00', 'bunny-landscape.jpg', 2),
(9, 'Railn', 25, '1997-04-30', 'Mandalay', 'min@gmail.com', 'male', 1, '2023-05-01 21:46:00', '611b5f8da375891b5883b83294527a15.jpg', 2),
(10, 'aung aung', 25, '2023-05-02', 'Yangon', 'aung@gmail.com', 'male', 1, '2023-06-08 12:55:00', 'c_13bLJk3.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hr_employees_employeemodel_tags`
--

CREATE TABLE IF NOT EXISTS `hr_employees_employeemodel_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employeemodel_id` int(11) NOT NULL,
  `employeetagmodel_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `hr_employees_employeemodel_tags`
--

INSERT INTO `hr_employees_employeemodel_tags` (`id`, `employeemodel_id`, `employeetagmodel_id`) VALUES
(2, 7, 3),
(6, 6, 1),
(7, 6, 2),
(8, 6, 3),
(9, 8, 2),
(10, 9, 1),
(11, 2, 1),
(12, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `hr_expences_expencemodel`
--

CREATE TABLE IF NOT EXISTS `hr_expences_expencemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employees_salary` varchar(20) NOT NULL,
  `office_uses` varchar(20) NOT NULL,
  `healthy_sequary` varchar(20) NOT NULL,
  `other_uses` varchar(20) NOT NULL,
  `uses_date` date NOT NULL,
  `note` longtext NOT NULL,
  `status` varchar(10) NOT NULL,
  `total_expenses` varchar(20) NOT NULL,
  `attachment` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hr_expences_expencemodel`
--

INSERT INTO `hr_expences_expencemodel` (`id`, `employees_salary`, `office_uses`, `healthy_sequary`, `other_uses`, `uses_date`, `note`, `status`, `total_expenses`, `attachment`) VALUES
(1, '200000', '200000', '20', '150000', '2023-05-31', 'Your developer is good job', 'Confirm', '750000090', 'bunny-landscape_sxdDIhA.jpg'),
(2, '90000000000', '20000000000000', '628891900', '20000088', '2023-05-28', 'Your developer is good job', 'draft', '47188888888888888880', 'bunny-landscape_Alnr8kQ.jpg'),
(3, '200000', '200000', '200000', '150000', '2023-04-05', 'hopwok', 'draft', '7500000', '1._Nan_Gyi_Thoke.webp');

-- --------------------------------------------------------

--
-- Table structure for table `hr_jobs_jobmodel`
--

CREATE TABLE IF NOT EXISTS `hr_jobs_jobmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `sequence` int(11) NOT NULL,
  `open_date` date NOT NULL,
  `expected_salary` varchar(20) NOT NULL,
  `note` longtext NOT NULL,
  `status` varchar(10) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `create_date` datetime NOT NULL,
  `attachment` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hr_jobs_jobmodel_department_id_cac3ead6_fk_hr_depart` (`department_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `hr_jobs_jobmodel`
--

INSERT INTO `hr_jobs_jobmodel` (`id`, `name`, `sequence`, `open_date`, `expected_salary`, `note`, `status`, `is_active`, `create_date`, `attachment`, `department_id`) VALUES
(1, 'Web Department', 3, '2023-05-01', '3000000', 'rtt', 'draft', 0, '2023-04-10 03:54:28', 'watch.jpg', 5),
(2, 'Senior Developer', 3, '2023-05-01', '3000000', 'wss', 'draft', 0, '2023-05-07 03:53:36', 'images_kq13DgT.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `hr_jobs_jobmodel_tags`
--

CREATE TABLE IF NOT EXISTS `hr_jobs_jobmodel_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobmodel_id` int(11) NOT NULL,
  `jobtagmodel_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hr_jobs_jobmodel_tags_jobmodel_id_jobtagmodel_id_ff8e3541_uniq` (`jobmodel_id`,`jobtagmodel_id`),
  KEY `hr_jobs_jobmodel_tag_jobtagmodel_id_4b42092e_fk_hr_tags_j` (`jobtagmodel_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hr_jobs_jobmodel_tags`
--

INSERT INTO `hr_jobs_jobmodel_tags` (`id`, `jobmodel_id`, `jobtagmodel_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_pages_pagemodel`
--

CREATE TABLE IF NOT EXISTS `hr_pages_pagemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `hr_payroles_payrolemodel`
--

CREATE TABLE IF NOT EXISTS `hr_payroles_payrolemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `department` varchar(20) NOT NULL,
  `join_date` date NOT NULL,
  `basic_salary` varchar(20) NOT NULL,
  `meal_allowance` varchar(20) NOT NULL,
  `travelling_allowance` varchar(20) NOT NULL,
  `total_salary` varchar(20) NOT NULL,
  `daily_wages` varchar(20) NOT NULL,
  `tax_deduction` varchar(20) NOT NULL,
  `other_deduction` varchar(20) NOT NULL,
  `ot_amt` varchar(20) NOT NULL,
  `next_salary` varchar(20) NOT NULL,
  `attachment` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hr_payroles_payrolemodel`
--

INSERT INTO `hr_payroles_payrolemodel` (`id`, `name`, `position`, `department`, `join_date`, `basic_salary`, `meal_allowance`, `travelling_allowance`, `total_salary`, `daily_wages`, `tax_deduction`, `other_deduction`, `ot_amt`, `next_salary`, `attachment`) VALUES
(1, 'Mg Mg', 'Junior', 'Senior Developer', '2013-06-02', '$250', '$50', '$30', '$380', '$3', '$20', '$2', '$36', '$288', 'bunny-landscape_CJStGnn.jpg'),
(3, 'pyae phyo', 'Junior', 'Junior Department', '2022-06-02', '$180000', '$20', '$23', '$20000000', '$30', '$20', '$20', '$36', '$25000000', 'bunny-landscape_5BsNyxt.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hr_recruitments_resumemodel`
--

CREATE TABLE IF NOT EXISTS `hr_recruitments_resumemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `sequence` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `note` longtext NOT NULL,
  `status` varchar(10) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `create_date` datetime NOT NULL,
  `attachment` varchar(100) NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `hr_recruitments_resumemodel`
--

INSERT INTO `hr_recruitments_resumemodel` (`id`, `name`, `sequence`, `appointment_date`, `note`, `status`, `is_active`, `create_date`, `attachment`, `employee_id`) VALUES
(1, 'Jon Hoop', 70, '2023-04-02', 'For this page', 'draft', 0, '2023-03-02 15:07:00', '', 2),
(2, 'min min', 20, '2023-03-28', 'this ia a very good', 'draft', 1, '2023-03-27 15:17:00', 'tree-736885__480_XQsUYsI.jpg', 5),
(3, 'khin zin', 12, '2023-03-28', 'this ia a very good', 'Confirm', 1, '2023-03-29 15:17:00', '301_1_9orbDwg.jpg', 0),
(6, 'khin khin', 29, '2023-03-27', 'this ia a very good', 'Confirm', 1, '2023-04-08 03:44:00', '301_1_lebuHtQ.jpg', 0),
(7, 'khin', 6, '2023-04-21', 'this ia a very good', 'Confirm', 1, '2023-04-21 16:37:00', 'c_FWN8fRN.jpg', 2),
(8, 'khin khin', 4, '2023-05-09', 'wefew', 'draft', 0, '2023-05-06 04:31:41', 'c_ybMb00u.jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `hr_recruitments_resumemodel_tags`
--

CREATE TABLE IF NOT EXISTS `hr_recruitments_resumemodel_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resumemodel_id` int(11) NOT NULL,
  `resumetagmodel_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `hr_recruitments_resumemodel_tags`
--

INSERT INTO `hr_recruitments_resumemodel_tags` (`id`, `resumemodel_id`, `resumetagmodel_id`) VALUES
(1, 8, 1),
(3, 1, 1),
(4, 1, 2),
(5, 7, 1),
(6, 7, 2),
(7, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_tags_contracttagmodel`
--

CREATE TABLE IF NOT EXISTS `hr_tags_contracttagmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `hr_tags_contracttagmodel`
--

INSERT INTO `hr_tags_contracttagmodel` (`id`, `name`) VALUES
(1, 'First Interview'),
(2, 'Second Interview');

-- --------------------------------------------------------

--
-- Table structure for table `hr_tags_employeetagmodel`
--

CREATE TABLE IF NOT EXISTS `hr_tags_employeetagmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hr_tags_employeetagmodel`
--

INSERT INTO `hr_tags_employeetagmodel` (`id`, `name`) VALUES
(1, 'Full time'),
(2, 'Part Time'),
(3, 'Free Leanser');

-- --------------------------------------------------------

--
-- Table structure for table `hr_tags_jobtagmodel`
--

CREATE TABLE IF NOT EXISTS `hr_tags_jobtagmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `hr_tags_jobtagmodel`
--

INSERT INTO `hr_tags_jobtagmodel` (`id`, `name`) VALUES
(1, 'Close'),
(2, 'Open');

-- --------------------------------------------------------

--
-- Table structure for table `hr_tags_resumetagmodel`
--

CREATE TABLE IF NOT EXISTS `hr_tags_resumetagmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `hr_tags_resumetagmodel`
--

INSERT INTO `hr_tags_resumetagmodel` (`id`, `name`) VALUES
(1, 'First Interview'),
(2, 'Second Interview');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `hr_contracts_contractmodel`
--
ALTER TABLE `hr_contracts_contractmodel`
  ADD CONSTRAINT `hr_contracts_contrac_employee_id_4d158874_fk_hr_employ` FOREIGN KEY (`employee_id`) REFERENCES `hr_employees_employeemodel` (`id`);

--
-- Constraints for table `hr_contracts_contractmodel_tags`
--
ALTER TABLE `hr_contracts_contractmodel_tags`
  ADD CONSTRAINT `hr_contracts_contrac_contractmodel_id_66f2432d_fk_hr_contra` FOREIGN KEY (`contractmodel_id`) REFERENCES `hr_contracts_contractmodel` (`id`),
  ADD CONSTRAINT `hr_contracts_contrac_contracttagmodel_id_ce805036_fk_hr_tags_c` FOREIGN KEY (`contracttagmodel_id`) REFERENCES `hr_tags_contracttagmodel` (`id`);

--
-- Constraints for table `hr_jobs_jobmodel`
--
ALTER TABLE `hr_jobs_jobmodel`
  ADD CONSTRAINT `hr_jobs_jobmodel_department_id_cac3ead6_fk_hr_depart` FOREIGN KEY (`department_id`) REFERENCES `hr_departments_departmentmodel` (`id`);

--
-- Constraints for table `hr_jobs_jobmodel_tags`
--
ALTER TABLE `hr_jobs_jobmodel_tags`
  ADD CONSTRAINT `hr_jobs_jobmodel_tag_jobmodel_id_d91bee4f_fk_hr_jobs_j` FOREIGN KEY (`jobmodel_id`) REFERENCES `hr_jobs_jobmodel` (`id`),
  ADD CONSTRAINT `hr_jobs_jobmodel_tag_jobtagmodel_id_4b42092e_fk_hr_tags_j` FOREIGN KEY (`jobtagmodel_id`) REFERENCES `hr_tags_jobtagmodel` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
