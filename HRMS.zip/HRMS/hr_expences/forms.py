from django import forms
from django.forms import widgets
from .models import ExpenceModel

STATUS_CHOICES =(
('draft', 'draft'),
('Confirm', 'confirm'),
('Cancel', 'cancel')
)

class ExpenceForm(forms.ModelForm):

    class Meta:
        model = ExpenceModel
        fields = "__all__"

        labels = {
        'employees_salary':'Enter Employees Salary', 
        'office_uses':'Enter OFfice Uses',
        'healthy_sequary':'Enter Heathy And Sequary', 
        'other_uses':'Enter Other Uses',
        'note':'Enter Note',
        'status':'Enter Status',
        'total_expenxes':'Enter Total Expenses',        

        }

        widgets = {
        'employees_salary': widgets.TextInput(attrs={'placeholder':'Employees Salary','class': 'form-control'}),
        'office_uses': widgets.TextInput(attrs={'placeholder':'OFfice  Uses', 'class': 'form-control'}),
        'healthy_sequary': widgets.TextInput(attrs={'placeholder':'Healthy And Sequary', 'class': 'form-control'}),
        'other_uses': widgets.TextInput(attrs={'placeholder':'Other Uses', 'class': 'form-control'}),
        'uses_date': widgets.DateInput(attrs={'placeholder':'Uses Date', 'type':  'date', 'class': 'form-control'}),
        'note': widgets.TextInput(attrs={'placeholder':'Internal Note', 'class': 'form-control'}),
        'status': widgets.Select(choices=STATUS_CHOICES),
        'total_expenses': widgets.TextInput(attrs={'placeholder':'Total Expeses','class': 'form-control'}),
        'attachment': widgets.ClearableFileInput(),


        }
