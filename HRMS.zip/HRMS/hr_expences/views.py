from django.shortcuts import render, redirect

# Create your views here.
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_expences import models
from hr_expences import forms
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator

from django.db.models import Q
from django.views import View
from .models import ExpenceModel

class SearchBy(View):

    def get(self, request):
        search = request.GET.get('search')
        if search:    
            expence = ExpenceModel.objects.filter(
                Q(employees_salary__icontains=search) |  
                Q(other_uses__icontains=search) |
                Q(uses_date__icontains=search) |
                Q(note__icontains=search)    
            )
        else:      
            expence = ExpenceModel.objects.all()
        return render(request, 'expence_list.html', {'all_expences': expence})

class OrderBy(View):

    def get(self, request):
        order = request.GET.get('order')
        expence = ExpenceModel.objects.all().order_by("-"+ order)
        order_selected = {str(order): 'btn-primary text-white'}
        return render(request, 'expence_list.html', {'all_expences': expence, 'order_selected': order_selected})

class ExpenceListView(LoginRequiredMixin,ListView):
	 paginate_by = 2
	 login_url = 'login'
	 model = models.ExpenceModel
	 context_object_name = 'all_expences'
	 template_name = 'expence_list.html'


class ExpenceDetailView(PermissionRequiredMixin,DetailView):
	 permission_required = 'hr_expences.add_expencemodel'
	 login_url = 'login'
	 model = models.ExpenceModel
	 form_class = forms.ExpenceForm
	 context_object_name = "expence"
	 template_name = 'expence_detail.html'

	 def get_context_data(self, **kwargs):
			context = super(ExpenceDetailView, self).get_context_data(**kwargs)
			expence = models.ExpenceModel.objects.get(id=self.kwargs.get('pk'))
			form = forms.ExpenceForm(instance=expence)
			context['form'] = form
			return context
		 
class ExpenceUpdateView(PermissionRequiredMixin,UpdateView):
	 permission_required = 'hr_expences.change_expencemodel'
	 login_url = 'login'
	 success_url = reverse_lazy("expence_list")
	 model = models.ExpenceModel
	 form_class = forms.ExpenceForm
	 context_object_name = "expence"
	 template_name = 'expence_update.html'


class ExpenceCreateView(PermissionRequiredMixin,CreateView):
	 permission_required = 'hr_expences.add_expencemodel'
	 login_url = 'login'
	 success_url = reverse_lazy("expence_list")
	 model = models.ExpenceModel
	 form_class = forms.ExpenceForm
	 template_name = 'expence_create.html'


class ExpenceDeleteView(PermissionRequiredMixin,DeleteView):
	 permission_required = 'hr_expences.delete_expencemodel'
	 login_url = 'login'
	 # success_url = reverse_lazy("expence_list")
	 # model = models.ExpenceModel
	 # context_object_name = "expence"
	 # template_name = 'expence_delete.html'

	 def get(self, request, pk):
			expence = models.ExpenceModel.objects.get(id=pk)  
			expence.delete()
			return redirect('expence_list')