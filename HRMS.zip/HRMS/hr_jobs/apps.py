from django.apps import AppConfig


class HrJobsConfig(AppConfig):
    name = 'hr_jobs'
