from django.apps import AppConfig


class HrRecruitmentsConfig(AppConfig):
    name = 'hr_recruitments'
