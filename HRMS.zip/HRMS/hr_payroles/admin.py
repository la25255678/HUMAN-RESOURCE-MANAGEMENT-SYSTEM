from django.contrib import admin

# Register your models here.
from hr_payroles.models import PayroleModel
admin.site.register(PayroleModel)