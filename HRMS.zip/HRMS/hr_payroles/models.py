from django.db import models
from django.utils import timezone

# Create your models here.
class PayroleModel(models.Model):
    name = models.CharField(max_length=20, verbose_name='Name')
    position = models.CharField(max_length=20, verbose_name='Position')
    department = models.CharField(max_length=20, verbose_name='Department')
    join_date = models.DateField(verbose_name='Join Date', default=timezone.now)
    basic_salary = models.CharField(max_length=20, verbose_name='Basic Salary', default=None)
    meal_allowance = models.CharField(max_length=20, verbose_name='Meal Allowance', default=None)
    travelling_allowance = models.CharField(max_length=20, verbose_name='Travelling Allowance', default=None)
    total_salary = models.CharField(max_length=20, verbose_name='Total Salary', default=None)
    daily_wages = models.CharField(max_length=20, verbose_name='Daily Wages', default=None)
    tax_deduction = models.CharField(max_length=20, verbose_name='Tax Deduction', default=None)
    other_deduction = models.CharField(max_length=20, verbose_name='Other Deduction', default=None)
    ot_amt = models.CharField(max_length=20, verbose_name='OT Amt', default=None)
    next_salary = models.CharField(max_length=20, verbose_name='Next Salary', default=None)
    attachment = models.ImageField(verbose_name='Image', default=None, blank=True)

    def __str__(self):
        return self