from django.shortcuts import render, redirect

# Create your views here.
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_payroles import models
from hr_payroles import forms
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator

from django.db.models import Q
from django.views import View
from .models import PayroleModel

class SearchBy(View):

    def get(self, request):
        search = request.GET.get('search')
        if search:    
            payrole = PayroleModel.objects.filter(
                Q(name__icontains=search) | 
                Q(position__icontains=search) |
                Q(department__icontains=search) |
                Q(join_date__icontains=search) |
                Q(basic_salary__icontains=search) |
                Q(next_salary__icontains=search) 
                   
            )
        else:      
            payrole = PayroleModel.objects.all()
        return render(request, 'payrole_list.html', {'all_payroles': payrole})

class OrderBy(View):

    def get(self, request):
        order = request.GET.get('order')
        payrole = PayroleModel.objects.all().order_by("-"+ order)
        order_selected = {str(order): 'btn-primary text-white'}
        return render(request, 'payrole_list.html', {'all_payroles': payrole, 'order_selected': order_selected})

class PayroleListView(LoginRequiredMixin,ListView):
	 paginate_by = 2 
	 login_url = 'login'
	 model = models.PayroleModel
	 context_object_name = 'all_payroles'
	 template_name = 'payrole_list.html'


class PayroleDetailView(PermissionRequiredMixin,DetailView):
 	 permission_required = 'hr_payroles.add_payrolemodel'
 	 login_url = 'login'
 	 model = models.PayroleModel
 	 context_object_name = "payrole"
 	 template_name = 'payrole_detail.html'

 	 def get_context_data(self, **kwargs):
				context = super(PayroleDetailView, self).get_context_data(**kwargs)
				payrole = models.PayroleModel.objects.get(id=self.kwargs.get('pk'))
				form = forms.PayroleForm(instance=payrole)
				context['form'] = form
				return context
		 
class PayroleUpdateView(PermissionRequiredMixin,UpdateView):
	 permission_required = 'hr_payroles.add_payrolemodel'
	 login_url = 'login'
	 success_url = reverse_lazy("payrole_list")
	 model = models.PayroleModel
	 form_class = forms.PayroleForm
	 context_object_name = "payrole"
	 template_name = 'payrole_update.html'


class PayroleCreateView(PermissionRequiredMixin,CreateView):
	 permission_required = 'hr_payroles.add_payrolemodel'
	 login_url = 'login'
	 success_url = reverse_lazy("payrole_list")
	 model = models.PayroleModel
	 form_class = forms.PayroleForm
	 template_name = 'payrole_create.html'


class PayroleDeleteView(PermissionRequiredMixin,DeleteView):
 	 permission_required = 'hr_payroles.add_payrolemodel'
 	 login_url = 'login'
	 # success_url = reverse_lazy("payrole_list")
	 # model = models.PayroleModel
	 # context_object_name = "payrole"
	 # template_name = 'payrole_delete.html'

 	 def get(self, request, pk):
 			payrole = models.PayroleModel.objects.get(id=pk)  
 			payrole.delete()
 			return redirect('payrole_list')